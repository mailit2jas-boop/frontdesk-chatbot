---
title: Chat With Your Documents
emoji: 💬
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 8501
pinned: false
short_description: Chat with your documents — answers cite their sources.
---

# 💬 Chat with your documents

A **retrieval-augmented generation (RAG)** chatbot. Upload your own PDF, Word,
text, or Markdown files and ask questions about them — every answer is drawn only
from your documents and cites which file it came from, so nothing is made up. If
the bot can't answer, it says so honestly and offers to pass your question to a
human.

## How it works

1. **Ingestion** — your document is split into overlapping chunks.
2. **Retrieval** — the most relevant chunks are found with semantic search (Chroma).
3. **Augmentation** — those chunks are placed into the prompt alongside your question.
4. **Generation** — a language model (Llama 3.3 70B via Groq) writes a grounded answer.

## Try it

- Ask the preloaded sample document a question, **or**
- Upload your own file in the sidebar and ask about it.

> This is a public demo — please don't upload confidential files.

## Configuration

The model is set in `config.py` and talks to any OpenAI-compatible API. The API key
is read from the `GROQ_API_KEY` environment variable (set as a Space secret).
