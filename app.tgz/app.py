"""Web demo — a grounded RAG chatbot that answers ONLY from your documents and proves it.

Features: streaming answers, click-to-verify citations, honest refusals, starter
questions, a retrieval transparency panel, white-label persona/branding, multi-document
synthesis, conversational follow-ups, auto document summaries, polished status,
transcript export, Word/PDF/text uploads, demo usage limits, human handoff when the
bot can't answer, and lead capture. It reuses retrieve()/build_prompt() from chat.py
and chunk_text() from ingest.py, so the terminal and web versions can never drift apart.

    streamlit run app.py
"""

import os
import re
import csv
import glob
import uuid
import hashlib
import threading
from io import BytesIO
from datetime import datetime
from collections import deque

import chromadb
import requests
import streamlit as st
from dotenv import load_dotenv
from pypdf import PdfReader
from docx import Document as DocxDocument

import config
from llm import generate, generate_stream
from chat import retrieve, build_prompt, REFUSAL_MESSAGE
from ingest import chunk_text

load_dotenv()

SAMPLE_SUMMARY = (
    "A sample knowledge base for the fictional clinic **Bright Smile Dental** — "
    "insurance & billing FAQ, a price list, and after-visit care instructions. "
    "Ask it anything a patient might — or upload your own documents in the sidebar."
)
SAMPLE_QUESTIONS = [
    "Which insurance plans do you accept?",
    "How much does a cleaning cost?",
    "What should I do after a tooth extraction?",
    "Do you offer payment plans?",
]


# --------------------------------------------------------------------------- #
#  Indexing helpers
# --------------------------------------------------------------------------- #
def read_upload(name: str, data: bytes) -> str:
    """Extract text from an uploaded file's bytes based on its extension.

    Returns "" for anything unreadable (corrupt, encrypted, or a renamed
    fake) instead of raising — a prospective client dragging in a bad file
    must NEVER see a red traceback on the demo. Empty text flows into the
    existing friendly "couldn't read those files" fallback.
    """
    lower = name.lower()
    try:
        if lower.endswith(".pdf"):
            reader = PdfReader(BytesIO(data))
            # Only the first MAX_PDF_PAGES pages: a public demo shouldn't grind
            # through a 900-page manual (slow + easy way to abuse the service).
            return "\n".join(
                (page.extract_text() or "") for page in reader.pages[: config.MAX_PDF_PAGES]
            )
        if lower.endswith(".docx"):
            doc = DocxDocument(BytesIO(data))
            parts = [p.text for p in doc.paragraphs]
            # Word tables aren't in .paragraphs; flatten them row by row so
            # pricing sheets and FAQ tables stay searchable.
            for table in doc.tables:
                parts += (" | ".join(cell.text for cell in row.cells) for row in table.rows)
            return "\n".join(parts)
        return data.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def build_collection(named_texts, name=None):
    """Build an in-memory, cosine-distance Chroma collection from (name, text) pairs.

    Nothing is written to disk. NOTE: in chromadb, separate EphemeralClient()
    instances share one in-memory database. Uploads pass a deterministic `name`
    (derived from the file signature) so a re-upload reuses one slot instead of
    piling up; we delete any existing collection of that name first so re-adds
    can't duplicate. The sample KB passes no name (a fresh uuid each build).
    """
    client = chromadb.EphemeralClient()
    coll_name = name or f"docs_{uuid.uuid4().hex}"
    if name:
        try:
            client.delete_collection(coll_name)  # avoid duplicate re-add on a cache miss
        except Exception:
            pass
    collection = client.create_collection(
        coll_name, metadata={"hnsw:space": "cosine"}
    )
    documents, ids, metadatas = [], [], []
    for file_idx, (source, text) in enumerate(named_texts):
        for i, chunk in enumerate(chunk_text(text, config.CHUNK_SIZE, config.CHUNK_OVERLAP)):
            documents.append(chunk)
            ids.append(f"{file_idx}-{source}-{i}")  # globally unique even if two files share a name
            metadatas.append({"source": source})
    if documents:
        collection.add(documents=documents, ids=ids, metadatas=metadatas)
    return collection, documents


def _sample_paths():
    return sorted(
        glob.glob(os.path.join(config.DOCS_DIR, "**", "*.md"), recursive=True)
        + glob.glob(os.path.join(config.DOCS_DIR, "**", "*.txt"), recursive=True)
    )


def sample_signature():
    """Cache key that changes whenever a file under documents/ is edited or added."""
    return hashlib.md5(
        "".join(f"{p}:{os.path.getmtime(p)}" for p in _sample_paths()).encode()
    ).hexdigest()


@st.cache_resource(show_spinner=False)
def sample_collection(signature):
    # `signature` only keys the cache (see sample_signature) so edits to the
    # sample docs are picked up without restarting the server.
    named = []
    for p in _sample_paths():
        with open(p, "r", encoding="utf-8") as f:
            named.append((os.path.basename(p), f.read()))
    return build_collection(named)


# Remember which upload collections exist so we can actually DELETE the oldest
# from Chroma's shared in-memory store — the @st.cache_resource decorator only
# drops the Python reference, which wouldn't free the embeddings themselves.
_upload_names = deque()
_upload_lock = threading.Lock()
_MAX_UPLOAD_COLLECTIONS = 8


@st.cache_resource(show_spinner=False, max_entries=5, ttl=3600)
def uploaded_collection(signature: str, _files):
    # `signature` keys the cache; `_files` is ignored for hashing (leading _).
    named = [(f.name, read_upload(f.name, f.getvalue())) for f in _files]
    coll_name = f"docs_{signature}"
    result = build_collection(named, name=coll_name)
    with _upload_lock:
        if coll_name in _upload_names:
            _upload_names.remove(coll_name)
        _upload_names.append(coll_name)
        # Kept larger than the cache's max_entries so we never delete a
        # collection a live session might still be using.
        while len(_upload_names) > _MAX_UPLOAD_COLLECTIONS:
            old = _upload_names.popleft()
            try:
                chromadb.EphemeralClient().delete_collection(old)
            except Exception:
                pass
    return result


# --------------------------------------------------------------------------- #
#  Model helpers (all degrade gracefully on API/rate-limit errors)
# --------------------------------------------------------------------------- #
def safe_generate(prompt: str, max_tokens: int):
    """Non-streaming model call that returns None instead of raising."""
    try:
        return generate(prompt, config.LLM_MODEL, max_tokens)
    except Exception:
        return None


def stream_answer(prompt: str):
    """Yield the answer token-by-token; degrade gracefully on API errors.

    Dollar signs are escaped because Streamlit's markdown treats $...$ as
    math notation — without this, "$210-$280" renders as garbled formulas,
    and prices come up constantly in dental/business documents.
    """
    try:
        for token in generate_stream(prompt, config.LLM_MODEL, config.MAX_TOKENS):
            yield token.replace("$", "\\$")
    except Exception as exc:
        yield (
            f"\n\n⚠️ I couldn't reach the model just now ({type(exc).__name__}). "
            "On the free tier this is usually a brief rate limit — please wait a few "
            "seconds and try again."
        )


def rewrite_query(question: str, history) -> str:
    """Rewrite a follow-up into a standalone search query using recent history.

    Without this, 'what about the second one?' embeds the pronoun and retrieves
    garbage. Skipped on the first turn (no history) to save a round-trip.
    """
    if not history:
        return question
    convo = "\n".join(f"User: {u}\nAssistant: {a}" for u, a in history[-config.HISTORY_TURNS:])
    prompt = (
        "Given the conversation, rewrite the user's last message as a single, standalone "
        "search query that includes any context it relies on. Return ONLY the query.\n\n"
        f"{convo}\nUser: {question}\n\nStandalone query:"
    )
    return (safe_generate(prompt, 60) or question).strip().strip('"')


@st.cache_data(show_spinner=False)
def doc_overview(cache_key: str, _texts):
    """Summarise a document set and suggest 4 questions (one cached LLM call)."""
    excerpt = "\n\n".join(_texts[:8])[:6000]
    prompt = (
        "Here is a document (or set of documents):\n\n" + excerpt + "\n\n"
        "Write a 2-3 sentence summary, then exactly 4 short example questions a user might "
        "ask about it. Respond EXACTLY in this format:\n"
        "SUMMARY: <summary>\nQUESTIONS:\n- <q1>\n- <q2>\n- <q3>\n- <q4>"
    )
    out = safe_generate(prompt, 300)
    if not out:
        return "", []
    summary, questions = out.strip(), []
    if "QUESTIONS:" in out:
        head, _, tail = out.partition("QUESTIONS:")
        summary = head.replace("SUMMARY:", "").strip()
        for line in tail.splitlines():
            q = line.strip().lstrip("-*0123456789. ").strip()
            if q:
                questions.append(q)
    return summary, questions[:4]


# --------------------------------------------------------------------------- #
#  UI helpers
# --------------------------------------------------------------------------- #
def inject_css(accent: str):
    """Brand the buttons with the accent color — keeping the text readable.

    If a client picks a very light accent (pale yellow/teal), accent-colored
    text on a white page becomes invisible, and white text on an accent hover
    fill does too. So the label/hover-text colors are chosen from the accent's
    brightness instead of being hard-wired.
    """
    accent = accent if re.fullmatch(r"#[0-9A-Fa-f]{6}", accent or "") else config.ACCENT_COLOR
    r, g, b = (int(accent[i : i + 2], 16) for i in (1, 3, 5))
    luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b  # 0 (black) – 255 (white)
    label = accent if luminance < 160 else "#1f2937"    # dark text on light accents
    hover_text = "#ffffff" if luminance < 160 else "#111827"
    css = f"""
        <style>
        .stButton > button {{ border: 1px solid {accent}; color: {label}; background: transparent;
                             border-radius: 8px; font-weight: 500; }}
        .stButton > button:hover {{ background: {accent}; color: {hover_text}; border-color: {accent}; }}
        #MainMenu, footer {{ visibility: hidden; }}
        </style>
    """
    st.markdown(css, unsafe_allow_html=True)


def _csv_safe(value) -> str:
    """Stop spreadsheet-formula injection: a visitor-typed value starting with
    = + - @ (or tab/CR) would otherwise execute as a formula when the owner
    opens leads.csv in Excel. A leading apostrophe forces plain text."""
    s = str(value)
    return "'" + s if s and s[0] in "=+-@\t\r" else s


def save_lead(kind: str, name: str, email: str, message: str) -> None:
    """Record a contact/handoff request: append to the CSV, and — if a
    LEADS_WEBHOOK env var is set (e.g. a Google Apps Script or Zapier URL) —
    also POST it there, best-effort.

    The webhook matters on hosted demos: free Hugging Face Spaces wipe the
    disk on every restart, so a CSV alone can silently lose a real inquiry.
    """
    row = [datetime.now().isoformat(timespec="seconds"), kind, name, email, message]
    is_new = not os.path.exists(config.LEADS_FILE)
    with open(config.LEADS_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if is_new:
            writer.writerow(["when", "type", "name", "email", "message"])
        writer.writerow([_csv_safe(v) for v in row])

    webhook = os.getenv("LEADS_WEBHOOK", "")
    if webhook:
        try:
            requests.post(
                webhook,
                json={"when": row[0], "type": kind, "name": name, "email": email, "message": message},
                timeout=5,
            )
        except requests.RequestException:
            pass  # never let a webhook hiccup break the visitor's form


def lead_form(form_key: str, kind: str, prompt: str, prefill_msg: str = "") -> None:
    """A small name/email/message form that saves a lead. Reused in two places."""
    with st.form(form_key, clear_on_submit=True):
        name = st.text_input("Your name", key=f"{form_key}-name")
        email = st.text_input("Email", key=f"{form_key}-email")
        message = st.text_area(prompt, value=prefill_msg, height=80, key=f"{form_key}-msg")
        if st.form_submit_button("Send"):
            if email.strip() and message.strip():
                save_lead(kind, name.strip(), email.strip(), message.strip())
                st.success("Thanks! Your message was saved — I'll follow up by email.")
            else:
                st.error("Please add your email and a short message.")


def build_transcript() -> str:
    lines = [f"# Conversation with {st.session_state.bot_name}", ""]
    for t in st.session_state.turns:
        lines += [f"**You:** {t['q']}", "", f"**{st.session_state.bot_name}:** {t['a']}"]
        if t.get("sources"):
            lines += ["", "_Sources: " + ", ".join(sorted(set(t["sources"]))) + "_"]
        lines.append("\n---\n")
    return "\n".join(lines)


def render_sources(turn):
    """Multi-doc badges (feature 7), click-to-verify citations (2), transparency (5)."""
    chunks, sources, dists = turn["chunks"], turn["sources"], turn["dists"]
    if not sources:
        return
    st.markdown("**Sources:** " + "  ".join(f"`{s}`" for s in sorted(set(sources))))
    for i, (chunk, src, dist) in enumerate(zip(chunks, sources, dists), start=1):
        rel = max(0.0, 1 - dist)
        with st.expander(f"[{i}] {src} · {rel:.0%} match"):
            st.markdown(chunk.replace("$", "\\$"))  # $...$ would render as math
    with st.expander("🔍 How this answer was found"):
        st.caption(
            f"Retrieved the top {len(chunks)} passages by meaning "
            f"(Top-K = {turn.get('top_k', len(chunks))}). Lower cosine distance = closer match."
        )
        for i, (src, dist) in enumerate(zip(sources, dists), start=1):
            st.write(f"`[{i}]` **{src}** — distance {dist:.3f}")


# --------------------------------------------------------------------------- #
#  Page setup + session defaults
# --------------------------------------------------------------------------- #
st.set_page_config(
    page_title=config.APP_NAME, page_icon=config.APP_ICON, layout="centered",
    initial_sidebar_state="expanded",  # visitors should see the upload panel immediately
)
st.session_state.setdefault("bot_name", config.APP_NAME)
st.session_state.setdefault("persona", config.DEFAULT_PERSONA)
st.session_state.setdefault("accent", config.ACCENT_COLOR)
st.session_state.setdefault("top_k", config.TOP_K)
st.session_state.setdefault("turns", [])
st.session_state.setdefault("pending_q", None)
st.session_state.setdefault("q_count", 0)  # survives "Clear chat" on purpose

# Per-client demo links: ?name=Bright%20Smile%20Dental&color=0e9f8a&persona=...
# lets the owner send each prospect a link already branded for THEM. Applied
# once per visit (so the visitor's own sidebar edits aren't overwritten on
# rerun) and sanitized — this is a public URL, not trusted input.
if not st.session_state.get("_qp_applied"):
    qp = st.query_params
    if qp.get("name"):
        st.session_state.bot_name = qp["name"][:60]
    if re.fullmatch(r"#?[0-9A-Fa-f]{6}", qp.get("color", "")):
        st.session_state.accent = "#" + qp["color"].lstrip("#")
    if qp.get("persona"):
        st.session_state.persona = qp["persona"][:500]
    st.session_state._qp_applied = True

# A missing model key would otherwise surface as a confusing "rate limit"
# message on every question — say what's actually wrong, up front.
if not os.getenv(config.LLM_API_KEY_ENV):
    st.warning(
        f"⚠️ The AI model key is missing — put {config.LLM_API_KEY_ENV}=... in the "
        ".env file (or the host's secrets) or answers won't work."
    )


# --------------------------------------------------------------------------- #
#  Sidebar — upload + white-label controls + tools
# --------------------------------------------------------------------------- #
with st.sidebar:
    st.header("📂 Documents")
    files = st.file_uploader(
        "Upload .pdf, .docx, .txt, or .md files",
        type=["pdf", "docx", "txt", "md"],
        accept_multiple_files=True,
        label_visibility="collapsed",
    )
    # Demo limits: cap how many files and how big, so one visitor can't
    # monopolise the free-tier API quota the demo runs on.
    if files and len(files) > config.MAX_UPLOAD_FILES:
        st.warning(f"Demo limit — using only the first {config.MAX_UPLOAD_FILES} files.")
        files = files[: config.MAX_UPLOAD_FILES]
    if files:
        too_big = [f.name for f in files if f.size > config.MAX_UPLOAD_MB * 1024 * 1024]
        if too_big:
            st.warning(
                f"Skipped (over {config.MAX_UPLOAD_MB} MB): " + ", ".join(too_big)
            )
            files = [f for f in files if f.name not in too_big]
    if files:
        st.success(f"{len(files)} file(s) loaded.")
    else:
        st.info("Using the built-in sample knowledge base.")

    with st.expander("⚙️ Customize assistant (white-label)"):
        st.session_state.bot_name = st.text_input("Assistant name", st.session_state.bot_name)
        st.session_state.persona = st.text_area(
            "Persona / instructions", st.session_state.persona, height=120
        )
        st.session_state.accent = st.color_picker("Accent color", st.session_state.accent)

    st.session_state.top_k = st.slider(
        "Passages to retrieve (Top-K)", 1, 8, st.session_state.top_k,
        help="How many document chunks to pull back for each question.",
    )

    c1, c2 = st.columns(2)
    if c1.button("🧹 Clear chat", width="stretch"):
        st.session_state.turns = []
        st.rerun()
    c2.download_button(
        "⬇️ Transcript",
        build_transcript(),
        file_name="chat-transcript.md",
        width="stretch",
        disabled=not st.session_state.turns,
    )
    with st.expander("📨 Contact — get a bot like this for your business"):
        lead_form("contact_form", "contact", "What do you need?")

    st.caption("⚠️ Public demo — please don't upload confidential files.")

    st.divider()
    if config.BUILDER_NAME == "Your Name":
        # Loud on purpose: this must never quietly ship to a public demo.
        st.warning("Almost ready: put your real name in config.py (BUILDER_NAME) "
                   "before sharing this link.")
    st.markdown(f"**Built by {config.BUILDER_NAME}**  \n{config.BUILDER_TAGLINE}")
    contact_line = f"📧 [{config.BUILDER_EMAIL}](mailto:{config.BUILDER_EMAIL})"
    if config.BUILDER_LINK:
        contact_line += f" · [Hire me]({config.BUILDER_LINK})"
    st.markdown(contact_line)


# --------------------------------------------------------------------------- #
#  Branding header (read AFTER the sidebar so edits apply this run)
# --------------------------------------------------------------------------- #
inject_css(st.session_state.accent)
st.title(f"{config.APP_ICON} {st.session_state.bot_name}")
st.caption("Answers come only from the documents below — and every claim cites its source.")


# --------------------------------------------------------------------------- #
#  Pick + index the active knowledge base (feature 10: visible status)
# --------------------------------------------------------------------------- #
if files:
    # Hash file CONTENT (not just name+size) so an edited-but-same-named file
    # re-indexes instead of returning a stale cached collection/summary.
    signature = hashlib.md5(
        "".join(sorted(f"{f.name}:{hashlib.md5(f.getvalue()).hexdigest()}" for f in files)).encode()
    ).hexdigest()
    try:
        with st.status("Reading and indexing your documents…", expanded=False) as status:
            collection, docs = uploaded_collection(signature, files)
            status.update(
                label=f"✅ Indexed {len(files)} file(s) → {len(docs)} passages", state="complete"
            )
    except Exception:
        # Backstop: whatever goes wrong reading/indexing, a prospect must see
        # a friendly message, never a traceback.
        collection, docs = None, []
    if not docs:
        st.warning(
            "I couldn't read any text from those files — they may be scanned images, "
            "corrupted, or password-protected. Try a text-based PDF, .docx, or .txt "
            "file. Showing the sample meanwhile."
        )
        collection, docs = sample_collection(sample_signature())
        summary, questions, active = SAMPLE_SUMMARY, SAMPLE_QUESTIONS, "the sample knowledge base"
    else:
        summary, questions = doc_overview(signature, docs)
        active = f"your {len(files)} uploaded file(s)"
else:
    collection, docs = sample_collection(sample_signature())
    summary, questions, active = SAMPLE_SUMMARY, SAMPLE_QUESTIONS, "the sample knowledge base"

st.caption(f"📚 Active knowledge base: **{active}** · {len(docs)} passages indexed")
if summary:
    st.info(f"**Overview:** {summary}")


# --------------------------------------------------------------------------- #
#  Conversation
# --------------------------------------------------------------------------- #
# Resolve the incoming question (typed, or from a clicked starter chip).
typed = st.chat_input(
    f"Ask {st.session_state.bot_name} about your documents",
    max_chars=config.MAX_QUESTION_CHARS,
)
question = typed or st.session_state.pending_q
st.session_state.pending_q = None

# Demo limit: pause after N questions per visit so a public link can't be
# used to drain the API quota. Doubles as a soft call-to-action. Detected
# here but DRAWN after the replay loop, so the message appears at the bottom
# of the conversation like any other turn (not pinned above older messages).
blocked_question = None
if question and st.session_state.q_count >= config.MAX_QUESTIONS_PER_SESSION:
    blocked_question = question
    question = None

# Replay the conversation so far.
for turn in st.session_state.turns:
    st.chat_message("user").write(turn["q"])
    with st.chat_message("assistant"):
        if turn.get("refused"):
            st.warning(turn["a"])
        else:
            st.markdown(turn["a"])
            render_sources(turn)

if blocked_question:
    st.chat_message("user").write(blocked_question)
    st.chat_message("assistant").warning(
        f"This public demo pauses after {config.MAX_QUESTIONS_PER_SESSION} questions per "
        f"visit. Want an unlimited version trained on your own documents? Use the contact "
        f"form in the sidebar or email {config.BUILDER_EMAIL}."
    )

# Starter-question chips (feature 4) — only before the conversation begins.
# For uploads we only show chips the model actually generated; we never fall
# back to the Acme sample questions under someone else's document.
chips = questions if questions else ([] if files else SAMPLE_QUESTIONS)
if not st.session_state.turns and not question and chips:
    st.markdown("**Try asking:**")
    cols = st.columns(2)
    for i, q in enumerate(chips[:4]):
        if cols[i % 2].button(q, key=f"chip-{i}", width="stretch"):
            st.session_state.pending_q = q
            st.rerun()

if question:
    st.session_state.q_count += 1
    st.chat_message("user").write(question)
    history = [(t["q"], t["a"]) for t in st.session_state.turns if not t.get("refused")]
    with st.chat_message("assistant"):
        try:
            with st.status("Searching your documents…", expanded=False) as status:
                try:
                    search_q = rewrite_query(question, history)
                    chunks, sources, dists = retrieve(collection, search_q, st.session_state.top_k)
                    status.update(label=f"Found {len(chunks)} relevant passages", state="complete")
                except Exception:
                    status.update(label="Search failed", state="error")
                    raise

            best = min(dists) if dists else 99.0
            if not chunks or best > config.RELEVANCE_THRESHOLD:
                # Feature 3 — honest, visible refusal when nothing is relevant enough.
                msg = (
                    "I couldn't find that in your documents. Try rephrasing, or upload a "
                    "document that covers it."
                )
                st.warning(msg)
                st.session_state.turns.append({"q": question, "a": msg, "refused": True})
            else:
                prompt = build_prompt(question, chunks, history, st.session_state.persona)
                answer = st.write_stream(stream_answer(prompt))  # feature 1 — streaming
                # The MODEL can also refuse (the prompt tells it to say the
                # canonical sentence when the retrieved passages don't answer
                # the question). Treat that exactly like a threshold refusal.
                # BUT only when the refusal sentence essentially IS the whole
                # reply — otherwise a compound answer that answers half and
                # refuses the other half ("...costs $210 [1]. However, I
                # couldn't find that...") would wrongly wipe a good cited
                # answer. So: contains the phrase, has NO citations, and is
                # short. Normalized because models vary apostrophes/quotes.
                needle = REFUSAL_MESSAGE.lower().rstrip(".")
                stripped = (answer or "").lower().replace("’", "'").strip().strip('"“”').strip()
                model_refused = (
                    needle in stripped
                    and re.search(r"\[\d+\]", stripped) is None
                    and len(stripped) <= len(needle) + 80
                )
                if not answer or answer.lstrip().startswith("⚠️"):
                    # Transient model error or empty reply: shown once, but NOT saved —
                    # so a brief rate limit can't poison history or the transcript.
                    if not answer:
                        st.warning("The model returned an empty response — please try again.")
                elif model_refused:
                    msg = (
                        "I couldn't find that in your documents. Try rephrasing, or upload a "
                        "document that covers it."
                    )
                    st.session_state.turns.append({"q": question, "a": msg, "refused": True})
                else:
                    turn = {
                        "q": question, "a": answer, "chunks": chunks, "sources": sources,
                        "dists": dists, "top_k": st.session_state.top_k,
                    }
                    render_sources(turn)
                    st.session_state.turns.append(turn)
        except Exception as exc:
            # Never show a raw traceback to a prospective client.
            st.error(
                f"Something went wrong handling that question ({type(exc).__name__}). "
                "Please try again in a moment."
            )

# Human handoff — when the bot just refused, offer a person instead. The
# unanswered question is pre-filled so the visitor only adds their email.
if st.session_state.turns and st.session_state.turns[-1].get("refused"):
    with st.expander("🙋 Want a human to answer this? Leave a message"):
        lead_form(
            "handoff_form", "handoff", "Your question",
            prefill_msg=st.session_state.turns[-1]["q"],
        )
