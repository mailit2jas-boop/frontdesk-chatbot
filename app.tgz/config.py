"""Every setting you might want to change lives here, in one place.

Open this file first. Tweak a number, re-run, see what changes. That's the
fastest way to build intuition for how a RAG system behaves.
"""

# --- Where things live ---
DOCS_DIR = "documents"     # put your .md and .txt files in this folder
DB_DIR = "chroma_db"       # the local vector database is written here
COLLECTION = "knowledge"   # the name of the collection inside that database

# --- How documents get split into chunks (measured in characters) ---
CHUNK_SIZE = 800           # how big each chunk is
CHUNK_OVERLAP = 150        # characters shared between neighbouring chunks, so a
                           # sentence isn't sliced cleanly in half at the seam

# --- Retrieval ---
TOP_K = 5                  # how many chunks to pull back for each question
                           # (5 so cross-topic questions still reach a 2nd/3rd doc)
# Collections use COSINE distance (0 = identical, 2 = opposite). If the best
# matching chunk is farther away than this, we skip the model call and refuse.
# Kept LENIENT (0.90) on purpose: the prompt already tells the model to refuse
# when the answer isn't in the context, so this gate only needs to catch
# clearly off-topic questions (observed ~0.89-0.96) — a strict gate would
# wrongly refuse terse-but-relevant client documents.
RELEVANCE_THRESHOLD = 0.90

# --- The language model that writes the answers ---
# This project talks to any OpenAI-compatible API, so switching providers means
# changing just these lines (and putting the matching key in your .env file):
#
#   Groq (free + fast):  base "https://api.groq.com/openai/v1"        key GROQ_API_KEY
#                        model "llama-3.3-70b-versatile"
#   Google Gemini (free):base "https://generativelanguage.googleapis.com/v1beta/openai/"
#                        key GEMINI_API_KEY   model "gemini-2.5-flash"
#   OpenAI:              base "https://api.openai.com/v1"             key OPENAI_API_KEY
LLM_BASE_URL = "https://api.groq.com/openai/v1"   # where the model lives
LLM_API_KEY_ENV = "GROQ_API_KEY"                  # name of the key in your .env
LLM_MODEL = "llama-3.3-70b-versatile"             # which model to call
MAX_TOKENS = 1000          # roughly the longest answer the model may write

# --- Memory ---
HISTORY_TURNS = 3          # how many recent back-and-forth turns to keep in the prompt

# --- Branding / persona (white-label: change these to reskin per client) ---
APP_NAME = "Bright Smile Dental — Front Desk Assistant"
APP_ICON = "🦷"
ACCENT_COLOR = "#0e9f8a"
DEFAULT_PERSONA = (
    "You are the front desk assistant for Bright Smile Dental — warm, clear, "
    "and careful. Answer patient questions from the clinic's documents only. "
    "Never give medical advice beyond what the documents say; for urgent "
    "problems, tell the patient to call the clinic."
)

# --- Demo protections (so a public link can't burn through your API quota) ---
MAX_QUESTIONS_PER_SESSION = 15   # questions per visit before the demo pauses
MAX_QUESTION_CHARS = 500         # longest question a visitor can type
MAX_UPLOAD_FILES = 3             # how many files a visitor may upload at once
MAX_UPLOAD_MB = 5                # biggest allowed size for each uploaded file
MAX_PDF_PAGES = 50               # only this many pages are read from each PDF

# --- You (shown in the footer; where leads and handoff requests go) ---
BUILDER_NAME = "Jaspreet Kaur"       # <-- put your name here
BUILDER_TAGLINE = "I build custom AI support agents for businesses."
BUILDER_EMAIL = "jasflora86@gmail.com"
BUILDER_LINK = "https://linkedin.com/in/jaspreetk91"                # optional: your Upwork profile / portfolio URL
LEADS_FILE = "leads.csv"         # contact + handoff messages are saved here
