# Bright Smile Dental — After Your Visit: Care Instructions

*Bright Smile Dental is a fictional clinic used to demonstrate this assistant.
These are general instructions — always follow the specific advice your
dentist gave you, and call the clinic if you're unsure.*

## After a tooth extraction

- **Bite gently on the gauze** for 30–45 minutes to help a blood clot form.
- **Do not rinse, spit forcefully, smoke, or drink through a straw for 24
  hours** — the suction can dislodge the clot and cause painful "dry socket."
- Some oozing and mild swelling is normal for 24–48 hours. Use an ice pack on
  the cheek, 10 minutes on / 10 minutes off, during the first day.
- Eat soft, cool foods (yogurt, smoothies without a straw, mashed potatoes)
  for the first day or two. Chew on the other side.
- From day 2, rinse gently with warm salt water (half a teaspoon of salt in a
  cup of warm water) after meals for a week.
- Take pain medication as directed. Over-the-counter ibuprofen or
  acetaminophen is usually enough.
- **Call us right away** if bleeding won't stop after an hour of firm gauze
  pressure, pain gets worse after day 3 instead of better, you develop a
  fever, or swelling spreads toward your eye or neck.

## After a filling

- Your mouth may be numb for 1–3 hours — be careful not to bite your cheek,
  lip, or tongue. Avoid hot drinks until feeling returns.
- Mild sensitivity to cold or pressure is normal for up to two weeks.
- If your bite feels "high" or uneven once the numbness wears off, call us —
  a quick, free adjustment fixes it.

## After teeth whitening

- Teeth are most stain-prone in the first 48 hours. Avoid coffee, tea, red
  wine, cola, berries, and smoking during that time — think "white foods."
- Temporary sensitivity is common and fades within a few days. A
  sensitivity toothpaste (used for a week) helps.

## After a crown or bridge

- With a **temporary** crown: avoid chewy or sticky foods (gum, caramel) and
  floss by sliding the floss out sideways rather than pulling up.
- Mild gum soreness for a few days is normal — warm salt-water rinses help.
- If a temporary or permanent crown comes loose or falls off, keep it and
  call us — do not glue it back yourself.

## After a root canal

- Avoid chewing on the treated tooth until the permanent filling or crown is
  placed — it can crack.
- Soreness for 2–4 days is normal, especially when biting. Ibuprofen usually
  controls it well.
- Call us if you have severe pain, visible swelling, or the temporary
  filling falls out.

## When in doubt

If anything feels wrong after a procedure, call the clinic at
(555) 013-7246. Describing your symptoms over the phone costs nothing and
helps us decide whether you should come in.
