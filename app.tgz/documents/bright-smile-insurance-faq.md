# Bright Smile Dental — Insurance & Billing FAQ

*Bright Smile Dental is a fictional clinic used to demonstrate this assistant.*

## Which insurance plans do you accept?

We accept most major dental insurance plans, including Sun Life, Manulife,
Canada Life, Green Shield, Blue Cross, and Desjardins. We also welcome
patients covered by the Canadian Dental Care Plan (CDCP).

If your insurer isn't listed, call our front desk — in most cases we can
still bill your plan directly.

## Do you bill my insurance directly?

Yes. We offer **direct billing** to most insurers, which means we submit the
claim for you and you only pay any remaining balance at your visit. Please
bring your insurance card (or a photo of it) to your first appointment.

## How much will my insurance cover?

Coverage depends on your specific plan. Typical plans cover:

- **Preventive care** (cleanings, checkups, x-rays): 80–100%
- **Basic restorative** (fillings, simple extractions): 50–80%
- **Major restorative** (crowns, bridges, dentures): 50%

We can send a **pre-determination** to your insurer before major work so you
know your out-of-pocket cost in advance — just ask.

## What if I don't have insurance?

No insurance is needed to be a patient here. See our price list for standard
fees. We also offer:

- **Payment plans** — larger treatments can be split into monthly payments,
  interest-free for up to 6 months. Ask the front desk for details.
- **New patient special** — your first exam, x-rays, and cleaning at a
  reduced package price.
- **Seniors discount** — 10% off for patients 65 and over.

## When is payment due?

Payment for your portion is due on the day of treatment. We accept debit,
Visa, Mastercard, American Express, and cash.

## Can I get a receipt for my records or taxes?

Yes — we provide an itemized receipt after every visit, and can re-issue
past receipts on request.

## Do you charge for missed appointments?

We ask for at least 48 hours' notice to change or cancel an appointment.
Missed appointments without notice may be charged a $50 fee, because that
time was reserved for you.

## Clinic hours and contact

- Monday–Thursday: 8:00 am – 6:00 pm
- Friday: 8:00 am – 4:00 pm
- Saturday: 9:00 am – 2:00 pm (twice a month)
- Sunday: closed

Phone: (555) 013-7246 · 123 Example Avenue, Springfield
