# Bright Smile Dental — Standard Fee Guide

*Bright Smile Dental is a fictional clinic used to demonstrate this assistant.
Prices are examples only.*

Fees follow the current provincial dental fee guide. Your exact cost can vary
with the complexity of your case — we always confirm the price with you
before starting treatment.

## Checkups & prevention

| Service | Fee |
|---|---|
| New patient exam (comprehensive) | $140 |
| Recall exam (returning patients) | $75 |
| Teeth cleaning (scaling, per unit) | $68 |
| Typical adult cleaning visit (3–4 units + polish) | $210–$280 |
| Polishing | $55 |
| Fluoride treatment | $35 |
| Full-mouth x-rays | $130 |
| Single x-ray (periapical) | $30 |

**New patient special:** exam + x-rays + cleaning package — $299.

## Fillings & repairs

| Service | Fee |
|---|---|
| White (composite) filling — 1 surface | $180 |
| White (composite) filling — 2 surfaces | $240 |
| White (composite) filling — 3+ surfaces | $310 |

## Extractions

| Service | Fee |
|---|---|
| Simple extraction | $220 |
| Surgical extraction | $380 and up |
| Wisdom tooth removal | quoted after exam and x-ray |

## Cosmetic & major work

| Service | Fee |
|---|---|
| In-office teeth whitening | $349 |
| Take-home whitening kit | $199 |
| Porcelain crown | $1,150 |
| Bridge (per unit) | $1,100 |
| Complete denture (upper or lower) | $1,600 |
| Root canal (front tooth) | $700 |
| Root canal (molar) | $1,050 |

## Emergencies

Same-day emergency exam (includes one x-ray): $95. We keep time open every
weekday for dental emergencies — call us as early in the day as you can.
