"""STEP 1 — Build the knowledge base.

Reads every document in the documents/ folder, splits each into overlapping
chunks, and stores them in a local vector database (Chroma). Chroma turns each
chunk into a vector using a small model it downloads automatically the first
time — so this step needs NO API key.

Run it once now, and re-run it whenever your documents change:

    python ingest.py
"""

import os
import glob

import chromadb

import config


def chunk_text(text: str, size: int, overlap: int) -> list:
    """Split text into chunks of `size` characters that overlap by `overlap`.

    Overlap matters: without it, an idea that lands right on a chunk boundary
    gets cut in half and becomes hard to retrieve. The overlap stitches the
    seams back together.
    """
    chunks = []
    start = 0
    step = max(1, size - overlap)  # guard: overlap >= size would loop forever
    while start < len(text):
        chunk = text[start:start + size].strip()
        if chunk:
            chunks.append(chunk)
        start += step
    return chunks


def main() -> None:
    # A persistent client writes the database to disk so it survives restarts.
    client = chromadb.PersistentClient(path=config.DB_DIR)

    # Start fresh each run so re-ingesting doesn't pile up duplicate chunks.
    try:
        client.delete_collection(config.COLLECTION)
    except Exception:
        pass
    # Use cosine distance so relevance scores are comparable across documents
    # (the web UI uses these to decide when to honestly say "not found").
    collection = client.create_collection(
        config.COLLECTION, metadata={"hnsw:space": "cosine"}
    )

    # Gather every .md and .txt file under the documents/ folder.
    paths = glob.glob(os.path.join(config.DOCS_DIR, "**", "*.md"), recursive=True)
    paths += glob.glob(os.path.join(config.DOCS_DIR, "**", "*.txt"), recursive=True)

    if not paths:
        print(f"No .md or .txt files found in '{config.DOCS_DIR}/'. Add some and try again.")
        return

    documents, ids, metadatas = [], [], []
    for path in paths:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        source = os.path.basename(path)
        for i, chunk in enumerate(chunk_text(text, config.CHUNK_SIZE, config.CHUNK_OVERLAP)):
            documents.append(chunk)
            ids.append(f"{source}-{i}")
            metadatas.append({"source": source})  # remembered so we can cite it later

    # This single call embeds every chunk and stores it. That's the whole
    # ingestion pipeline from the architecture diagram, in one line.
    collection.add(documents=documents, ids=ids, metadatas=metadatas)

    print(f"Ingested {len(documents)} chunks from {len(paths)} file(s).")
    print(f"Vector database saved to '{config.DB_DIR}/'.")
    print("Next:  python chat.py   (terminal)   or   streamlit run app.py   (browser)")


if __name__ == "__main__":
    main()
