"""The one and only place the language model is called.

Why isolate it? So the rest of the project never touches a model SDK directly.
This talks to any OpenAI-COMPATIBLE API (Groq, Google Gemini, OpenAI, Kimi, a
local model, ...). To switch providers you change three lines in config.py and
the key in your .env file — nothing else in the project changes.
"""

import os

from openai import OpenAI

import config

_client = None


def _get_client() -> OpenAI:
    """Create the client the first time it's needed.

    It reads the API key from the environment variable named in config
    (LLM_API_KEY_ENV) and points the OpenAI SDK at config.LLM_BASE_URL, so the
    same code works for Groq, Gemini, OpenAI, etc.
    """
    global _client
    if _client is None:
        api_key = os.getenv(config.LLM_API_KEY_ENV)
        if not api_key:
            raise RuntimeError(
                f"No API key found. Put {config.LLM_API_KEY_ENV}=... in your .env file. "
                f"For Groq, get a free key at https://console.groq.com"
            )
        _client = OpenAI(base_url=config.LLM_BASE_URL, api_key=api_key)
    return _client


def generate(prompt: str, model: str, max_tokens: int) -> str:
    """Send one prompt to the model and return the full text of its reply."""
    response = _get_client().chat.completions.create(
        model=model,
        max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content


def generate_stream(prompt: str, model: str, max_tokens: int):
    """Stream the reply token-by-token (a generator of text fragments).

    Used by the web UI so the answer 'types' itself like ChatGPT instead of
    appearing all at once after a pause.
    """
    stream = _get_client().chat.completions.create(
        model=model,
        max_tokens=max_tokens,
        stream=True,
        messages=[{"role": "user", "content": prompt}],
    )
    for chunk in stream:
        delta = chunk.choices[0].delta.content
        if delta:
            yield delta
